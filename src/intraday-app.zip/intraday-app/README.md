# Intraday Timer

Herramienta de análisis intradiario con Parabólico SAR, tendencia diaria, volumen y liquidez.

## Stack
- React 18 + Vite
- Sin dependencias externas de UI
- Precios en tiempo real vía Yahoo Finance

## Instrucciones para publicar en Vercel

### Opción A — Drag & Drop (más fácil)

1. Instalar dependencias localmente:
```bash
npm install
npm run build
```

2. Ir a [vercel.com](https://vercel.com)
3. Crear cuenta gratuita
4. En el dashboard: **"Add New Project"** → **"Browse"**
5. Subir la carpeta `dist/` que generó el build
6. Vercel publica automáticamente y te da una URL

### Opción B — GitHub + Vercel (recomendado para actualizaciones)

1. Crear repo en [github.com](https://github.com)
2. Subir todos los archivos de este proyecto
3. En Vercel: **"Import Git Repository"** → seleccionar el repo
4. Build settings (Vercel los detecta automáticamente):
   - Framework: **Vite**
   - Build command: `npm run build`
   - Output directory: `dist`
5. Deploy → URL pública lista

### Desarrollo local
```bash
npm install
npm run dev
```
Abre http://localhost:5173

## Notas
- Los precios en tiempo real funcionan en producción (Vercel)
- Se actualizan cada 30 segundos vía Yahoo Finance
- El sandbox de Claude.ai bloquea fetches externos (limitación del entorno)
